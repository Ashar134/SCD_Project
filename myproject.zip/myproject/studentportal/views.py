from django.shortcuts import render , HttpResponse

# Create your views here.

# Student Portal HomePage
def loadStudentPortalHome(request):
    return render(request, "student-portal-home.html")

# timetable 
def timetable(request):
    return HttpResponse("This is Timetable")

# worksheet
def worksheets(request):
    return HttpResponse("This is worksheet Page")

# todoVault
def todoVault(request):
    return HttpResponse("This is To-do Vault Page")

# discussion
def discussion(request):
    return HttpResponse("This is discussion Page")

# myteacher
def myteacher(request):
    return HttpResponse("This is myteacher Page")


# learning Resources
def learningResources(request):
    return HttpResponse("This is learning Resources Page")

