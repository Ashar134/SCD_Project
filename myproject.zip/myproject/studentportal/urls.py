from django.contrib import admin
from django.urls import path
from studentportal import views

urlpatterns = [
    path("" ,views.loadStudentPortalHome ,name='home' ),
    path("timetable" ,views.timetable ,name='timetable' ),
    path("worksheets" ,views.worksheets ,name='worksheets' ),
    path("todovault" ,views.todoVault ,name='todovault' ),
    path("discussion" ,views.discussion ,name='discussion' ),
    path("myteacher" ,views.myteacher ,name='myteacher' ),
    path("learningresources" ,views.learningResources ,name='learningresources' )



]
